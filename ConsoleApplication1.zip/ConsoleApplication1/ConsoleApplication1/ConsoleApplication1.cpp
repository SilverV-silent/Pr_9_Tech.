﻿#include <iostream>
#include <vector>
#include <string>
using namespace std;

// Структура для описания сотрудника
struct Employee {
    string fullName;
    char gender; // 'm'  для мужчин, 'f' for женщин
    int age;
    bool isMarried; // true есть пара, false нет пары
    bool hasChildren; // true если есть детки, false если нет
    string position;
    string academicDegree;
};

class LaboratoryModule {
private:
    vector<Employee> employees;
public:
    void addEmployee() {
        Employee newEmp;
        cout << "укажите полное : ";
        cin.ignore(); // Clear the input buffer
        getline(cin, newEmp.fullName);

        cout << "пол (мужской 'm' или  женский 'f'): ";
        cin >> newEmp.gender;

        cout << "возраст: ";
        cin >> newEmp.age;

        cout << "женат/замужем (y/n): ";
        char maritalStatus;
        cin >> maritalStatus;
        newEmp.isMarried = (maritalStatus == 'y');

        cout << "имеет детей (y/n): ";
        char childStatus;
        cin >> childStatus;
        newEmp.hasChildren = (childStatus == 'y');

        cout << "позиция: ";
        cin.ignore();
        getline(cin, newEmp.position);

        cout << "Академическая степень: ";
        getline(cin, newEmp.academicDegree);

        employees.push_back(newEmp); // Добавляем нового рабочего
        cout << "рабочий успешно добавлен." << endl;
    }

    void listEmployees() const {
        if (employees.empty()) {
            cout << "не найден в база данных." << endl;
            return;
        }

        cout << "\nList of Employees:\n";
        for (const auto& emp : employees) {
            cout << "полное имя: " << emp.fullName << endl;
            cout << "пол: " << ((emp.gender == 'm') ? "мужской" : "женский") << endl;
            cout << "возраст: " << emp.age << endl;
            cout << "женат/замужем " << ((emp.isMarried) ? "есть пара" : "одинок") << endl;
            cout << "имеет детей: " << ((emp.hasChildren) ? "да" : "нет") << endl;
            cout << "позиция: " << emp.position << endl;
            cout << "Академическая степень: " << emp.academicDegree << endl;
            cout << "----*>!~!<*----\n";
        }
    }

    void editEmployee() {
        string nameToEdit;
        cout << "Enter employee's full name to edit: ";
        cin.ignore();
        getline(cin, nameToEdit);

        for (auto& emp : employees) {
            if (emp.fullName == nameToEdit) {
                cout << "Editing details for " << emp.fullName << endl;

                cout << "New Position: ";
                getline(cin, emp.position);

                cout << "New Academic Degree: ";
                getline(cin, emp.academicDegree);

                cout << "Details updated.\n";
                return;
            }
        }
        cout << "рабочий не найден для изменений.\n";
    }

    void deleteEmployee() {
        string nameToDelete;
        cout << "укажите полное имя рабочего для удаления ";
        cin.ignore();
        getline(cin, nameToDelete);

        for (size_t i = 0; i < employees.size(); ++i) {
            if (employees[i].fullName == nameToDelete) {
                employees.erase(employees.begin() + i);
                cout << "рабочий успешно удалён/уволен.\n";
                return;
            }
        }
        cout << "работник не найден для удаления/увольнения.\n";
    }
};

int main() {
    LaboratoryModule labModule;
    int choice;

    while (true) {
        cout << "\nпрограммный модуль «Лаборатория» меню\n";
        cout << "1. добавить работника\n";
        cout << "2. список рабочих\n";
        cout << "3. настройки информации рабочего\n";
        cout << "4. убрать/уволить рабочего\n";
        cout << "5. выход\n";
        cout << "выберите функцию: ";
        cin >> choice;

        switch (choice) {
        case 1:
            labModule.addEmployee();
            break;
        case 2:
            labModule.listEmployees();
            break;
        case 3:
            labModule.editEmployee();
            break;
        case 4:
            labModule.deleteEmployee();
            break;
        case 5:
            exit(0);
        default:
            cout << "опция не существует или не доступна. попробуйте позже или выберите другую функцию.\n";
        }
    }
}
